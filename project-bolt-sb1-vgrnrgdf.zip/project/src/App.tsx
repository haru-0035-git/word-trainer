import { useState } from 'react';
import { Moon, Sun } from 'lucide-react';
import Quiz from './components/Quiz';
import Header from './components/Header';
import Footer from './components/Footer';

function App() {
  const [darkMode, setDarkMode] = useState(false);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  return (
    <div className={`min-h-screen ${darkMode ? 'dark bg-slate-900' : 'bg-gradient-to-br from-blue-50 via-white to-indigo-50'} transition-colors duration-300`}>
      <div className="container mx-auto px-4 py-8">
        <div className="absolute top-4 right-4">
          <button 
            onClick={toggleDarkMode} 
            className={`p-2 rounded-full ${darkMode ? 'bg-slate-700 text-yellow-300' : 'bg-indigo-100 text-indigo-800'} transition-colors duration-300`}
            aria-label={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
          >
            {darkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
        </div>
        
        <Header darkMode={darkMode} />
        <main className="mt-8">
          <Quiz darkMode={darkMode} />
        </main>
        <Footer darkMode={darkMode} />
      </div>
    </div>
  );
}

export default App;